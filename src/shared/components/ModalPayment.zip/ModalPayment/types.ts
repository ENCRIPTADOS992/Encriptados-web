export interface FormValuesPayment {
  email: string;
  telegramId?: string;
  termsAccepted: boolean;
}
