// src/shared/components/ModalPayment/ModalPaymentController.tsx
"use client";

import React from "react";
import { useModalPayment } from "@/providers/ModalPaymentProvider";
import ModalPayment from "./ModalPayment";
import ModalPaymentView from "./ModalPaymentView";

const ModalPaymentController = () => {
  const { isModalOpen, closeModal, params } = useModalPayment();
  const layout = (params as any)?.layout ?? "default";

  const panelClassName =
    layout === "compact"
      ? "p-3 sm:p-3 w-[380px] sm:max-w-[420px]"
      : "p-6 sm:max-w-4xl";

  return (
    <ModalPayment
      visible={isModalOpen}
      onClose={closeModal}
      theme={(params as any)?.theme ?? "light"}
      panelClassName={panelClassName}
    >
      <ModalPaymentView />
    </ModalPayment>
  );
};

export default ModalPaymentController;
