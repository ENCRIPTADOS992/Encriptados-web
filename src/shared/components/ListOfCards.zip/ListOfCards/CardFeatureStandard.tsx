// src/shared/components/CardFeatureStandard.tsx
"use client";

import React from "react";

interface CardFeatureStandardProps {
  icon: React.ReactElement;
  title: string;
  description: string;
}

const CardFeatureStandard: React.FC<CardFeatureStandardProps> = ({
  icon,
  title,
  description,
}) => {
  return (
    <div className="bg-[#111] text-white p-6 rounded-xl space-y-2 h-full">
      <div className="inline-block p-2 bg-[#222] rounded-lg">{icon}</div>
      <h3 className="text-white font-semibold text-base">{title}</h3>
      <p className="text-gray-400 text-sm">{description}</p>
    </div>
  );
};

export default CardFeatureStandard;
