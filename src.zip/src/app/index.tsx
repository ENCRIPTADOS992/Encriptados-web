const Index = () => {
  return <></>;
};

export default Index;
