import React from "react";
import RouterPage from "./components/RouterPage";

const Page = () => {
  return <RouterPage />;
};

export default Page;