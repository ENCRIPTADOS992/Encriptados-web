import React from "react";
import BlogPage from "./components/BlogPage";

const Page = () => {
  return <BlogPage />;
};

export default Page;
