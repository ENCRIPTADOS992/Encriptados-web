import React from 'react';

const SecurityTestPage = () => {
  return <div>Contenido del Test de Seguridad</div>;
};

export default SecurityTestPage;