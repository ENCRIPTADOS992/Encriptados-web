import React from "react";
import AboutUsPage from "./components/AboutUsPage";

const Page = () => {
  return <AboutUsPage />;
};

export default Page;


