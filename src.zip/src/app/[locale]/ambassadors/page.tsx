import React from "react";
import AmbassadorsPage from "./components/AmbassadorsPage";

const Page = () => {
  return (
    <>
      <AmbassadorsPage />
    </>
  );
};

export default Page;
