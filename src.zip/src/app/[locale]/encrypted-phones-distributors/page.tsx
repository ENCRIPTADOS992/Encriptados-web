import React from 'react';

const EncryptedPhonesDistributorsPage = () => {
  return <div>Celulares Encriptados Content</div>;
};

export default EncryptedPhonesDistributorsPage;