import React from "react";
import WhereToFindUsPage from "./components/WhereToFindUsPage";

const Page = () => {
  return <WhereToFindUsPage />;
};

export default Page;
