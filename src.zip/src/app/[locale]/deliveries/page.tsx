import React from "react";
import DeliveriePage from "./components/DeliveriePage";

const Page = () => {
  return <DeliveriePage />;
};

export default Page;
