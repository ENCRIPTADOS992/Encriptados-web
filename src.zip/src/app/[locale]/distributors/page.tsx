import React from "react";
import DistributorsPage from "./components/DistributorsPage";

const Page = () => {
  return <DistributorsPage />;
};

export default Page;
