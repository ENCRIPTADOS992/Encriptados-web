import React from 'react';

const BecomeEncryptedPartnerPage = () => {
  return <div>Contenido de Ser Socio de Encriptados</div>;
};

export default BecomeEncryptedPartnerPage;
