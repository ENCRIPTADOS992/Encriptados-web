import React from "react";

import ProductByIdPage from "./components/ProductByIdPage";

const page = () => {
  return <ProductByIdPage />;
};

export default page;
