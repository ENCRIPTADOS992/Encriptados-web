// src/app/[locale]/our-products/page.tsx

import OurProductsPageClient from "./components/OurProductsPageClient";

export default function OurProductsPage() {
  return <OurProductsPageClient />;
}
