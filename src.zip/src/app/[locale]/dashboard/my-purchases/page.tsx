import React from "react";
import MyPurchasesPage from "./components/MyPurchasesPage";

const Page = () => {
  return <MyPurchasesPage />;
};

export default Page;
