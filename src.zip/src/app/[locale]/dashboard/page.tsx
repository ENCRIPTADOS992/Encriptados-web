import { redirect } from "next/navigation";
const Dashboard = () => {
  redirect("/dashboard/data-usage");
};

export default Dashboard;
