import React from "react";
import AdminAccountPage from "./components/AdminAccountPage";

const Page = () => {
  return <AdminAccountPage />;
};

export default Page;
