import React from "react";

import WhereUseYourSim from "./WhereUseYourSim";

const MayaDataPage = () => {
  return (
    <>
      <div id="use-your-sim" className="w-full ">
        <WhereUseYourSim />
      </div>
    </>
  );
};

export default MayaDataPage;
