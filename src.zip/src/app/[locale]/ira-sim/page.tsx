import React from "react";
import MayaDataPage from "./components/MayaDataPage";

const Page = () => {
  return <MayaDataPage />;
};

export default Page;
