import React from "react";

export const PhoneGraphicSvg = () => {
  return <div>PhoneGraphicSvg</div>;
};
