import React from "react";
import EncryptedTestPage from "./components/EncryptedTestPage";

const page = () => {
  return <EncryptedTestPage />;
};

export default page;
