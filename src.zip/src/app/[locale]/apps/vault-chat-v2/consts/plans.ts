export const plans = [
  { label: 'Licencia 6 meses', value: '3' },
  { label: 'Licencia 12 meses', value: '6' },
];
