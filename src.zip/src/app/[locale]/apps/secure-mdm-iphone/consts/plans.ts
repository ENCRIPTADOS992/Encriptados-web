export const plans = [
  { label: '6 meses', value: '12.1' }
];