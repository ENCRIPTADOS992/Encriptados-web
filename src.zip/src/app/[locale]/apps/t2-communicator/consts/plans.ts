export const plans = [
  { label: 'Celular Encriptado', value: '0' },
  { label: 'Licencia 3 meses', value: '3' },
  { label: 'Licencia 6 meses', value: '6' }
];
