export const plans = [
  { label: 'Licencia 3 Meses', value: '3' },
  { label: 'Licencia 6 Meses', value: '6' }
];
