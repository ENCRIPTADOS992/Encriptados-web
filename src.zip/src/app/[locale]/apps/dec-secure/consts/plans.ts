export const plans = [
  { label: '3 meses', value: '3' },
  { label: '6 meses', value: '6' }
];
