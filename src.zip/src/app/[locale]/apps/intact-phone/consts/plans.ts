export const plans = [
  { label: 'Licencia 12 meses', value: '12.1' },
  { label: 'IntactPhone BOND Celular (12 Meses)', value: '12.2' },
  { label: 'IntactPhone ARCANE Celular (12 Meses)', value: '12.3' }
];
