import React from "react";
import ElyonPage from "./components/ElyonPage";

const Page = () => {
  return <ElyonPage />;
};

export default Page;