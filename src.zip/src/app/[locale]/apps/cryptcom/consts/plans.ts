export const plans = [
  { label: '3 Meses', value: '3' },
  { label: '6 Meses', value: '6' }
];
