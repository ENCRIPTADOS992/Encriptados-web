export const plans = [
  { label: 'Licencia 6 mes', value: '6' },
  { label: 'Licencia 12 meses', value: '12' },
  { label: 'Teléfono + 6 Meses de Licencia', value: '12.1' }
];
