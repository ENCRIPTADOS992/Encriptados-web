export const plans = [{ label: '12 Meses', value: '12' }];
