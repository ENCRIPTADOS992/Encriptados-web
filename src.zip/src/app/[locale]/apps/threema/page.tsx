import React from "react";
import ThreemaPage from "./components/ThreemaPage";

const Page = () => {
  return <ThreemaPage />;
};

export default Page;
