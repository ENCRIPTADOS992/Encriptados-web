export const plans = [
  { label: '1 Meses', value: '1' },
  { label: '6 Meses', value: '6' },
  { label: '12 Meses', value: '12' }
];

export const plansDesktop = [
  { label: 'Licencia 1 Mes', value: '1' },
  { label: 'Licencia 6 Meses', value: '6' },
  { label: 'Licencia 12 Meses', value: '12' }
];
