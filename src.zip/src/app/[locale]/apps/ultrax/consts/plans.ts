export const plans = [
  { label: 'Celular', value: '3' },
  { label: 'Licencia 3 Meses', value: '6' },
  { label: 'Licencia 6 Meses', value: '9' }
];
