export const plans = [{ label: 'Licencia 12 mes', value: '12' }];
