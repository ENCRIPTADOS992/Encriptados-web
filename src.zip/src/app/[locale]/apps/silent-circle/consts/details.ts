export const details = [
  'Construido sobre un protocolo fundamentalmente diferente',
  'Sin política de puerta trasera',
  'Diseño Privado',
  'Administración de usuarios',
  'Todos tus datos protegidos',
  'Tecnología patentada de grado militar'
];
