export const characteristics = [
  { label: '6 Meses', value: '6' }
];
