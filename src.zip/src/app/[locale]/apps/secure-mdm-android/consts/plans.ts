export const plans = [
  { label: '12 meses', value: '12.1' }
];