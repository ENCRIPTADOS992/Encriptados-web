import React from 'react';

const NewsPage = () => {
  return <div>Noticias Content</div>;
};

export default NewsPage;
