"use client";

import EncriptedSimPage from "./components/EncriptedSimPage";

const Page = () => {
  return (
    <>
      <EncriptedSimPage />
    </>
  );
};

export default Page;
