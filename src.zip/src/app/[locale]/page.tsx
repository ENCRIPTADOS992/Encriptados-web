import OurProductsPage from "./our-products/OurProductsPage";

export default function HomePage() {
  return (
    <>
      {/* Banner para dispositivos móviles */}

      <OurProductsPage />
    </>
  );
}
