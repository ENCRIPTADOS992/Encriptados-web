import BneSimPage from "./components/BneSimPage";

const Page = () => {
  return (
    <>
      <BneSimPage />
    </>
  );
};

export default Page;
