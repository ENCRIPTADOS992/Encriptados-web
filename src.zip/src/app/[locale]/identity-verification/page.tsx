import React from 'react';

const IdentityVerificationPage = () => {
  return <div>Verificación de Identidad Content</div>;
};

export default IdentityVerificationPage;