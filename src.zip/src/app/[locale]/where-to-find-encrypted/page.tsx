import React from 'react';

const AboutUsPage = () => {
  return <div>Contenido de Dónde Encontrar Encriptados</div>;
};

export default AboutUsPage;