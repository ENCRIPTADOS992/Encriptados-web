import FastDeliveryPage from "./components/FastDeliveryPage";

const Page = () => {
  return (
    <>
      <FastDeliveryPage />
    </>
  );
};

export default Page;
