export const PRODUCTS_QUERY_KEY = ["products"];

export const PRODUCT_BY_ID_QUERY_KEY = ["productbyid"];

export const PRODUCTS_BY_CATEGORY = ["productsByCategory"];
