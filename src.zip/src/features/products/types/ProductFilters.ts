export interface ProductFilters {
  selectedOption: string;
  provider: string;
  os: string;
  license: string;
  encriptadosprovider: string;
  timprovider: string;
  regionOrCountry?: string;
   regionOrCountryType?: "region" | "country";

}
