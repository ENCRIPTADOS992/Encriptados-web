export type RechargeBody = {
  number: string;
};

export type RechargeResponse = {
  number: string;
};
